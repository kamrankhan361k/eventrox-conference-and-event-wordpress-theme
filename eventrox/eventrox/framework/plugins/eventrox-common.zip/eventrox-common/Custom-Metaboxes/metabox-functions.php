<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
$textdomain = "eventrox";
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';
	
  
   
    // Add other metaboxes as needed
    
    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Image Recent Posts',
                'desc' => 'Background Projects Details',
                'id'   => $prefix . 'img_recent',
                'type'    => 'file',
            ),
            array(
                'name' => 'Image Blog Grid',
                'desc' => 'Background Blog Grid',
                'id'   => $prefix . 'image_grid',
                'type'    => 'file',
            ),
            

        )
    );

$meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('Event'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Gallery Image',
                'desc' => 'Background Projects Details',
                'id'   => $prefix . 'image_gallery',
                'type'    => 'file',
            ),
            array(
                'name' => 'Avatar Image',
                'desc' => 'Avatar',
                'id'   => $prefix . 'avatar',
                'type'    => 'file',
            ),
            array(
                'name' => 'Admin',
                'desc' => 'Admin',
                'id'   => $prefix . 'admin',
                'type'    => 'text',
            ),
            array(
                'name' => 'Job Admin',
                'desc' => 'Job Admin',
                'id'   => $prefix . 'job_admin',
                'type'    => 'text',
            ),
            array(
                'name' => 'Time Event',
                'desc' => 'Time Event',
                'id'   => $prefix . 'time_event',
                'type'    => 'text',
            ),
            array(
                'name' => 'Address Event',
                'desc' => 'Address Event',
                'id'   => $prefix . 'address_event',
                'type'    => 'text',
            ),
        )
    );




$meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('Speakers'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
         
            
            array(
                'name' => 'Link Facebook',
                'desc' => 'Link Facebook',
                'id'   => $prefix . 'facebook',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link Twitter',
                'desc' => 'Link Twitter',
                'id'   => $prefix . 'twitter',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link Pinterest',
                'desc' => 'Link Pinterest',
                'id'   => $prefix . 'pinterest',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link Dribbble',
                'desc' => 'Link Dribbble',
                'id'   => $prefix . 'dribbble',
                'type'    => 'text',
            ),
            array(
                'name' => 'Job',
                'desc' => 'Job',
                'id'   => $prefix . 'job',
                'type'    => 'text',
            ),
        )
    );


    return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

} 