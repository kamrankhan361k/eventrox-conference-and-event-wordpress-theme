<?php
// register post type Speakers
add_action( 'init', 'register_eventrox_Speakers' );
function register_eventrox_Speakers() {
    
$labels = array( 
'name' => __( 'Speakers', 'eventrox' ),
'singular_name' => __( 'Speakers', 'eventrox' ),
'add_new' => __( 'Add New Speakers', 'eventrox' ),
'add_new_item' => __( 'Add New Speakers', 'eventrox' ),
'edit_item' => __( 'Edit Speakers', 'eventrox' ),
'new_item' => __( 'New Speakers', 'eventrox' ),
'view_item' => __( 'View Speakers', 'eventrox' ),
'search_items' => __( 'Search Speakers', 'eventrox' ),
'not_found' => __( 'No Speakers found', 'eventrox' ),
'not_found_in_trash' => __( 'No Speakers found in Trash', 'eventrox' ),
'parent_item_colon' => __( 'Parent Speakers:', 'eventrox' ),
'menu_name' => __( 'Speakers', 'eventrox' ),
);

$args = array( 
'labels' => $labels,
'hierarchical' => true,
'description' => 'List Speakers',
'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
'taxonomies' => array( 'Speakers', 'type' ),
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'menu_position' => 5,
'menu_icon' => 'dashicons-universal-access', 
'show_in_nav_menus' => true,
'publicly_queryable' => true,
'exclude_from_search' => false,
'has_archive' => true,
'query_var' => true,
'can_export' => true,
'rewrite' => true,
'capability_type' => 'post'
);

register_post_type( 'Speakers', $args );
}
add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

$labels = array(
'name' => __( 'Type', 'eventrox' ),
'singular_name' => __( 'Type', 'eventrox' ),
'search_items' =>  __( 'Search Type','eventrox' ),
'all_items' => __( 'All Type','eventrox' ),
    'parent_item' => __( 'Parent Type','eventrox' ),
    'parent_item_colon' => __( 'Parent Type:','eventrox' ),
    'edit_item' => __( 'Edit Type','eventrox' ), 
    'update_item' => __( 'Update Type','eventrox' ),
    'add_new_item' => __( 'Add New Type','eventrox' ),
    'new_item_name' => __( 'New Type Name','eventrox' ),
    'menu_name' => __( 'Type','eventrox' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Speakers'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}


add_action( 'init', 'register_eventrox_Event' );
function register_eventrox_Event() {
    
$labels = array( 
'name' => __( 'Event', 'eventrox' ),
'singular_name' => __( 'Event', 'eventrox' ),
'add_new' => __( 'Add New Event', 'eventrox' ),
'add_new_item' => __( 'Add New Event', 'eventrox' ),
'edit_item' => __( 'Edit Event', 'eventrox' ),
'new_item' => __( 'New Event', 'eventrox' ),
'view_item' => __( 'View Event', 'eventrox' ),
'search_items' => __( 'Search Event', 'eventrox' ),
'not_found' => __( 'No Event found', 'eventrox' ),
'not_found_in_trash' => __( 'No Event found in Trash', 'eventrox' ),
'parent_item_colon' => __( 'Parent Event:', 'eventrox' ),
'menu_name' => __( 'Event', 'eventrox' ),
);

$args = array( 
'labels' => $labels,
'hierarchical' => true,
'description' => 'List Event',
'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
'taxonomies' => array( 'Event', 'type1' ),
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'menu_position' => 5,
'menu_icon' => 'dashicons-id-alt', 
'show_in_nav_menus' => true,
'publicly_queryable' => true,
'exclude_from_search' => false,
'has_archive' => true,
'query_var' => true,
'can_export' => true,
'rewrite' => true,
'capability_type' => 'post'
);

register_post_type( 'Event', $args );
}
add_action( 'init', 'create_Type1_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

$labels = array(
'name' => __( 'Type1', 'eventrox' ),
'singular_name' => __( 'Type1', 'eventrox' ),
'search_items' =>  __( 'Search Type1','eventrox' ),
'all_items' => __( 'All Type1','eventrox' ),
    'parent_item' => __( 'Parent Type1','eventrox' ),
    'parent_item_colon' => __( 'Parent Type1:','eventrox' ),
    'edit_item' => __( 'Edit Type1','eventrox' ), 
    'update_item' => __( 'Update Type1','eventrox' ),
    'add_new_item' => __( 'Add New Type1','eventrox' ),
    'new_item_name' => __( 'New Type1 Name','eventrox' ),
    'menu_name' => __( 'Type1','eventrox' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Event'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));

}


?>