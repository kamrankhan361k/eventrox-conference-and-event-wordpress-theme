<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsContactUs extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-contact';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Contact Us', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'contact' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_contact',

			[

				'label' => esc_html__( 'Contact Us Info', 'bdevs-elementor' ),

			]	

		);

		

		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Contact Us Info', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'title'   => esc_html__( 'title', 'bdevs-elementor' ),

						'subtitle' => esc_html__( 'subtitle', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],			

					[

						'name'        => 'subtitle',

						'label'       => esc_html__( 'Subtitle Items', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					

				],

			]

		);

		$this->add_control(

			'facebook',

			[

				'label'       => __( 'Link Facebook', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link Facebook', 'bdevs-elementor' ),

				'default'     => __( 'Link Facebook', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'twitter',

			[

				'label'       => __( 'Link Twitter', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link Twitter', 'bdevs-elementor' ),

				'default'     => __( 'Link Twitter', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'google',

			[

				'label'       => __( 'Link Google Plus', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link Google Plus', 'bdevs-elementor' ),

				'default'     => __( 'Link Google Plus', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'dribbble',

			[

				'label'       => __( 'Link Dribbble', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link Dribbble', 'bdevs-elementor' ),

				'default'     => __( 'Link Dribbble', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'pinterest',

			[

				'label'       => esc_html__( 'Link Pinterest', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link Pinterest', 'bdevs-elementor' ),

				'default'     => __( 'Link Pinterest', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		



		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_contact_form',

			[

				'label' => esc_html__( 'Contact form', 'bdevs-elementor' ),

			]	

		);

		

		$this->add_control(

			'heading2',

			[

				'label'       => __( 'Heading Contact form', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Heading Contact form', 'bdevs-elementor' ),

				'default'     => __( 'Heading Contact form', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		

		$this->add_control(

			'contact_form',

			[

				'label'       => __( 'Contact Form', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXTAREA,

				'placeholder' => __( 'Contact Form', 'bdevs-elementor' ),

				'default'     => __( 'Contact Form', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		



		$this->end_controls_section();

		/** 

		*	Layout section 

		**/

		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading Contact Info', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);			



		$this->add_control(

			'show_heading2',

			[

				'label'   => esc_html__( 'Show Heading Contact Form', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_icon',

			[

				'label'   => esc_html__( 'Show Icon', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_subtitle',

			[

				'label'   => esc_html__( 'Show Subtitle', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_facebook',

			[

				'label'   => esc_html__( 'Show Facebook', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_twitter',

			[

				'label'   => esc_html__( 'Show Twitter', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_google',

			[

				'label'   => esc_html__( 'Show Google Plus', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_dribbble',

			[

				'label'   => esc_html__( 'Show Dribbble', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_pinterest',

			[

				'label'   => esc_html__( 'Show Pinterest', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

	?> 
	<h2 style="display: none;">11111</h2>
	 <section class="contact-page-section">

        <div class="auto-container">

            <div class="row clearfix">

                <div class="contact-column col-lg-4 col-md-12 col-sm-12 order-2">

                    <div class="inner-column">

                    	<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                        <div class="sec-title">

                            <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                        </div>

                         <?php endif; ?>

                        <ul class="contact-info">

                        <?php

				        	$idd = 0;

				        	 foreach ( $settings['tabs'] as $item ) :

				        	 $idd++;?>



                            <li>

                            	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                                <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                                <?php endif; ?>

                                <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                <p><strong><?php echo wp_kses_post($item['title']); ?></strong></p>

                                <?php endif; ?>

                                <?php if (( '' !== $item['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>

                                <p><?php echo wp_kses_post($item['subtitle']); ?></p>

                                <?php endif; ?>

                            </li>



                        <?php endforeach; ?>

                            

                        </ul>



                        <ul class="social-icon-two social-icon-colored">

                        	<?php if (( '' !== $settings['facebook'] ) && ( $settings['show_facebook'] )) : ?>

                            <li><a href="<?php echo wp_kses_post($item['facebook']); ?>"><i class="fab fa-facebook"></i></a></li>

                            <?php endif; ?>

                            <?php if (( '' !== $settings['twitter'] ) && ( $settings['show_twitter'] )) : ?>

                            <li><a href="<?php echo wp_kses_post($item['twitter']); ?>"><i class="fab fa-twitter"></i></a></li>

                            <?php endif; ?>

                            <?php if (( '' !== $settings['google'] ) && ( $settings['show_google'] )) : ?>

                            <li><a href="<?php echo wp_kses_post($item['google']); ?>"><i class="fab fa-google-plus"></i></a></li>

                            <?php endif; ?>

                            <?php if (( '' !== $settings['dribbble'] ) && ( $settings['show_dribbble'] )) : ?>

                            <li><a href="<?php echo wp_kses_post($item['dribbble']); ?>"><i class="fab fa-dribbble"></i></a></li>

                            <?php endif; ?>

                            <?php if (( '' !== $settings['pinterest'] ) && ( $settings['show_pinterest'] )) : ?>

                            <li><a href="<?php echo wp_kses_post($item['pinterest']); ?>"><i class="fab fa-pinterest"></i></a></li>

                            <?php endif; ?>

                        </ul>

                    </div>

                </div>



                <!-- Form Column -->

                <div class="form-column col-lg-8 col-md-12 col-sm-12">

                    <div class="inner-column">

                        <div class="contact-form">

                        	<?php if (( '' !== $settings['heading2'] ) && ( $settings['show_heading2'] )) : ?>

                            <div class="sec-title">

                                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                            </div>

                            <?php endif; ?>

                            <?php echo do_shortcode($settings['contact_form']);?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    

	<?php

	}

}