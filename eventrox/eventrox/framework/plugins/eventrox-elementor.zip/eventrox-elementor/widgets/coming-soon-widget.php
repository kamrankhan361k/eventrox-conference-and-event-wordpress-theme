<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsComingSoon extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-coming-soon';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Coming Soon', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'coming soon' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_Coming',
			[
				'label' => esc_html__( 'Coming soon', 'bdevs-elementor' ),
			]	
		);	
		$this->add_control(
			'background_bg',
			[
				'label'       => esc_html__( 'Logo', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Signature Image', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter Subtitle', 'bdevs-elementor' ),
				'default'     => __( 'It is Subtitle', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'contact_form',
			[
				'label'       => __( 'Contact Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Contact Form', 'bdevs-elementor' ),
				'default'     => __( 'Contact Form', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'facebook',
			[
				'label'       => __( 'Link Facebook', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Link Facebook', 'bdevs-elementor' ),
				'default'     => __( 'Link Facebook', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'twitter',
			[
				'label'       => __( 'Twitter', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Link Twitter', 'bdevs-elementor' ),
				'default'     => __( 'Link Twitter', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'linkedin',
			[
				'label'       => __( 'Link Linkedin', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Link Linkedin', 'bdevs-elementor' ),
				'default'     => __( 'Link Linkedin', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'behance',
			[
				'label'       => __( 'Link Behance', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Link Behance', 'bdevs-elementor' ),
				'default'     => __( 'Link Behance', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'dribbble',
			[
				'label'       => __( 'Link Dribbble', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Link Dribbble', 'bdevs-elementor' ),
				'default'     => __( 'Link Dribbble', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		

		$this->end_controls_section();

		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'center',
			]
		);
		

		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_subtitle',
			[
				'label'   => esc_html__( 'Show Subtitle', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_facebook',
			[
				'label'   => esc_html__( 'Show Facebook', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_twitter',
			[
				'label'   => esc_html__( 'Show Twitter', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_linkedin',
			[
				'label'   => esc_html__( 'Show Linkedin', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_behance',
			[
				'label'   => esc_html__( 'Show Behance', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_dribbble',
			[
				'label'   => esc_html__( 'Show Dribbble', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		extract($settings);
		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );
	$bg_url = $bg_src ? $bg_src[0] : '';
	?> 
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	<!-- Header span -->

    <!-- Coming Soon -->
    <section class="coming-soon">
        <div class="anim-icons full-width">
            <span class="icon icon-circle-blue wow fadeIn"></span>
            <span class="icon icon-dots wow fadeInleft"></span>
            <span class="icon icon-line-1 wow zoomIn"></span>
            <span class="icon icon-circle-1 wow zoomIn"></span>
        </div>

        <div class="auto-container">
            <div class="content">
                <div class="logo"><a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php print esc_url( $bg_url ); ?>" alt=""></a></div>
                <?php if (( '' !== $settings['title'] ) && ( $settings['show_title'] )) : ?>
                <h1><?php echo wp_kses_post($settings['title']); ?></h1>
                <?php endif; ?>
                <?php if (( '' !== $settings['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>
                <div class="text"><?php echo wp_kses_post($settings['subtitle']); ?></div>
                <?php endif; ?>
                <div class="timer">
                    <div class="cs-countdown clearfix" data-countdown="12/1/2020 05:06:59"></div>            
                </div>
                <!--Emailed Form-->
                <div class="emailed-form">
                    <?php echo do_shortcode($settings['contact_form']);?>
                </div>
                <div class="social-links">
                    <ul class="social-icon-two social-icon-colored">
                    	<?php if (( '' !== $settings['facebook'] ) && ( $settings['show_facebook'] )) : ?>
                        <li><a href="<?php echo wp_kses_post($settings['facebook']); ?>"><span class="fab fa-facebook-f"></span></a></li>
                        <?php endif; ?>
                        <?php if (( '' !== $settings['twitter'] ) && ( $settings['show_twitter'] )) : ?>
                        <li><a href="<?php echo wp_kses_post($settings['twitter']); ?>"><span class="fab fa-twitter"></span></a></li>
                        <?php endif; ?>
                        <?php if (( '' !== $settings['linkedin'] ) && ( $settings['show_linkedin'] )) : ?>
                        <li><a href="<?php echo wp_kses_post($settings['linkedin']); ?>"><span class="fab fa-linkedin-in"></span></a></li>
                        <?php endif; ?>
                        <?php if (( '' !== $settings['behance'] ) && ( $settings['show_behance'] )) : ?>
                        <li><a href="<?php echo wp_kses_post($settings['behance']); ?>"><span class="fab fa-behance"></span></a></li>
                        <?php endif; ?>
                        <?php if (( '' !== $settings['dribbble'] ) && ( $settings['show_dribbble'] )) : ?>
                        <li><a href="<?php echo wp_kses_post($settings['dribbble']); ?>"><span class="fab fa-dribbble"></span></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- End Coming Soon -->
</div>
	<?php
	}

}