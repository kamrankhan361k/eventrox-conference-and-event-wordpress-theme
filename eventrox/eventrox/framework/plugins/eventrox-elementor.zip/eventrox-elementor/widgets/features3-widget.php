<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsFeatures3 extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-features3';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Features Style 3', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-slideshow';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'slides', 'carousel' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_features',

			[

				'label' => esc_html__( 'Features', 'bdevs-elementor' ),

			]	

		);



		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Features Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'delay',

						'label'       => esc_html__( 'Delay', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '0' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],		

					[

						'name'        => 'link_title',

						'label'       => esc_html__( 'Link Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' #' , 'bdevs-elementor' ),

						'label_block' => true,

					],				

					[

						'name'        => 'subtitle',

						'label'       => esc_html__( 'Subtitle Items', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					

				],

			]

		);



		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_subtitle',

			[

				'label'   => esc_html__( 'Show Subtitle', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_icon',

			[

				'label'   => esc_html__( 'Show Icon', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



	}



	public function render() {



		$settings  = $this->get_settings_for_display();

		extract($settings);

		?>  
		<h2 style="display: none;">11111</h2>
		<section class="features-section-three no-pd-top">

        <div class="auto-container">

            <div class="row">

                <!-- Feature Block -->

                <?php

        	$idd = 0;

        	 foreach ( $settings['tabs'] as $item ) :

        	 $idd++;

        	  ?>

                <div class="feature-block-three col-lg-6 col-md-12 col-sm-12 wow fadeInUp" data-wow-delay="<?php echo wp_kses_post($item['delay']); ?>">

                    <div class="inner-box">

                    	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                        <div class="icon-box"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span></div>

                        <?php endif; ?>

                        <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                        <h4><a href="<?php echo wp_kses_post($item['link_title']); ?>"><?php echo wp_kses_post($item['title']); ?></a></h4>

                        <?php endif; ?>

                        <?php if (( '' !== $item['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>

                        <div class="text"><?php echo wp_kses_post($item['subtitle']); ?></div>

                        <?php endif; ?>

                        <div class="link-box"><a href="<?php echo wp_kses_post($item['link_title']); ?>" class="theme-btn"><span class="fa fa-angle-right"></span></a></div>

                    </div>

                </div>

                <?php

					endforeach;

					?>

                <!-- Feature Block -->

                

            </div>

        </div>

    </section>

	<?php

	}



}

