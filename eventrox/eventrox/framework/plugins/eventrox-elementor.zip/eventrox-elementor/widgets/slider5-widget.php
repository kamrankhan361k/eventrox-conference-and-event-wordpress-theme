<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsSlider5 extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-slider5';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Slider Home Five', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-slideshow';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'slides5', 'carousel' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_sliders5',

			[

				'label' => esc_html__( 'Sliders Home Five', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'background_bg',

			[

				'label'       => esc_html__( 'Background Image', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'background_bg_2',

			[

				'label'       => esc_html__( 'Background Image 2', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);			

		$this->add_control(

			'link',

			[

				'label'       => __( 'Link', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Link', 'bdevs-elementor' ),

				'default'     => __( '#', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'button',

			[

				'label'       => __( 'Button', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Button', 'bdevs-elementor' ),

				'default'     => __( 'Booking Now', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);

		$this->add_control(

			'time',

			[

				'label'       => __( 'Time Countdown', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Time Countdown', 'bdevs-elementor' ),

				'default'     => __( '12/1/2020', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_time',

			[

				'label'   => esc_html__( 'Show Time Countdown', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



	}



	public function render() {



		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

	$bg_src_2 = wp_get_attachment_image_src( $settings['background_bg_2']['id'], 'full' );

	$bg_url_2 = $bg_src_2 ? $bg_src_2[0] : '';

		?>  
		<h2 style="display: none;">11111</h2>
    <section class="banner-conference-two" style="background-image: url(<?php print esc_url( $bg_url_2); ?>)">

        <!-- Icons -->

		<div class="icons parallax-scene-1">

			<!-- Icon One -->

			<div data-depth="0.20" class="icon-one parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-1.png)"></div>

			<!-- Icon Two -->

			<div data-depth="0.50" class="icon-two parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-2.png)"></div>

			<!-- Icon Three -->

			<div data-depth="0.10" class="icon-three parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-3.png)"></div>

			<!-- Icon Four -->

			<div data-depth="0.30" class="icon-four parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-4.png)"></div>

			<!-- Icon Five -->

			<div data-depth="0.10" class="icon-five parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-5.png)"></div>

			<!-- Icon Six -->

			<div data-depth="0.20" class="icon-six parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-6.png)"></div>

			<!-- Icon Seven -->

			<div data-depth="0.10" class="icon-seven parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-7.png)"></div>

			<!-- Icon One -->

			<div data-depth="0.20" class="icon-eight parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-1.png)"></div>

			<!-- Icon Two -->

			<div data-depth="0.50" class="icon-nine parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-8.png)"></div>

			<!-- Icon Three -->

			<div data-depth="0.10" class="icon-ten parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-3.png)"></div>

			<!-- Icon Four -->

			<div data-depth="0.30" class="icon-eleven parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-4.png)"></div>

			<!-- Icon Five -->

			<div data-depth="0.10" class="icon-twelve parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-5.png)"></div>

			<!-- Icon Six -->

			<div data-depth="0.20" class="icon-thirteen parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-6.png)"></div>

			<!-- Icon Seven -->

			<div data-depth="0.10" class="icon-fourteen parallax-layer" style="background-image:url(<?php echo get_template_directory_uri();?>/images/icons/icon-7.png)"></div>

		</div>

		<div class="images-outer">

            <figure class="speaker-img"><img src="<?php print esc_url( $bg_url ); ?>" alt=""></figure>

        </div>



        <div class="auto-container">

            <div class="content-box">

            	<?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

                <?php if (( '' !== $settings['time'] ) && ( $settings['show_time'] )) : ?>

                <div class="time-counter"><div class="time-countdown clearfix" data-countdown="<?php echo wp_kses_post($settings['time']); ?>"></div></div>

                <?php endif; ?>

                <?php if (( '' !== $settings['button'] ) && ( $settings['show_button'] )) : ?>

                <div class="btn-box"><a href="<?php echo wp_kses_post($settings['link']); ?>" class="theme-btn btn-style-two"><span class="btn-title"><?php echo wp_kses_post($settings['button']); ?></span></a></div>

                <?php endif; ?>

            </div>

        </div>

    </section>
<?php if (is_admin()) { ?>
    <script type="text/javascript">
    
        
            
		var $this = $(this), finalDate = $(this).data('countdown');
		$this.countdown(finalDate, function(event) {
			var $this = $(this).html(event.strftime('' + '<div class="counter-column"><span class="count">%D</span>Days</div> ' + '<div class="counter-column"><span class="count">%H</span>Hours</div>  ' + '<div class="counter-column"><span class="count">%M</span>Minutes</div>  ' + '<div class="counter-column"><span class="count">%S</span>Second</div>'));
		});
	 
        
        
    </script>   
    <?php } ?>
	<?php

	}



}

