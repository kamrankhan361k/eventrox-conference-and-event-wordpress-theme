<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsGallery extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-gallery';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Gallery', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'gallery' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_gallery',

			[

				'label' => esc_html__( 'Gallery', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'style_01'  => esc_html__( 'Gallery Style 1 ', 'bdevs-elementor' ),

					'style_02' => esc_html__( 'Gallery Style 2 ', 'bdevs-elementor' ),

				],

				'default'   => ['style_01'],

			]

		);

		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Type section title here', 'bdevs-elementor' ),

				'condition' => [

							'chose_style' => ['style_01'],

						],

			]

		);



		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXTAREA,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'condition' => [

							'chose_style' => ['style_01'],

						],

			]

		);

		$this->add_control(

			'post_number',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'3'  => esc_html__( '3', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'9' => esc_html__( '9', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

					'15' => esc_html__( '15', 'bdevs-elementor' ),

					'18' => esc_html__( '18', 'bdevs-elementor' ),

					'21' => esc_html__( '21', 'bdevs-elementor' ),

					'24' => esc_html__( '24', 'bdevs-elementor' ),

					'27' => esc_html__( '27', 'bdevs-elementor' ),

					'30' => esc_html__( '30', 'bdevs-elementor' ),

				],

				'default'   => '6',

			]

		);



		$this->add_control(

			'orderpost',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->add_control(

			'orderby',

			[

				'label'     => esc_html__( 'Order By', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'date'  => esc_html__( 'Date', 'bdevs-elementor' ),

					'title' => esc_html__( 'Title', 'bdevs-elementor' ),

					'rand' => esc_html__( 'Random', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->end_controls_section();



		/** 

		*	Layout section 

		**/

		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);			



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		$wp_query = new \WP_Query(array('posts_per_page' => $settings['post_number'],'post_type' => 'event',  'orderby' => $orderby, 'order' => $orderpost));

		$args = array('posts_per_page' => $settings['post_number'],'post_type' => 'event',  'orderby' => $orderby, 'order' => $orderpost);

		extract($settings);?> 
		<h2 style="display: none;">11111</h2>
		<?php if( $chose_style == 'style_01' ): ?>

		<section class="gallery-section">   

        <div class="auto-container">

            <div class="sec-title text-center">

            	<?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>	

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>	

            </div>



            <div class="row">

            	<?php 

                        $args = new \WP_Query(array(

	                    'post_type'     => 'event',

	                    

	                ));

                                $i = 1;

                                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                                $i++;

								?>

				<?php $image_gallery = get_post_meta(get_the_ID(),'_cmb_image_gallery', true); ?>

                <div class="gallery-item col-lg-4 col-md-6 col-sm-12 wow fadeIn">

                    <div class="image-box">

                        <figure class="image"><img src="<?php echo esc_attr($image_gallery);?>" alt=""></figure>

                        <div class="overlay-box"><a href="<?php echo esc_attr($image_gallery);?>" class="lightbox-image" data-fancybox='gallery'><span class="icon fa fa-expand-arrows-alt"></span></a></div>

                    </div>

                </div>

                <?php 

                    endwhile; ?>

                

            </div>

        </div>

    </section>

		<?php elseif( $chose_style == 'style_02' ): ?>

	<section class="gallery-section style-two">
		<h2 style="display: none;">11111</h2>
        <div class="gallery-carousel owl-carousel owl-theme">

            

        	<?php 

                        $args = new \WP_Query(array(

	                    'post_type'     => 'event',

	                    

	                ));

                                $i = 1;

                                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                                $i++;

								?>

				<?php $image_gallery = get_post_meta(get_the_ID(),'_cmb_image_gallery', true); ?>



            <div class="gallery-item">

                <div class="image-box">

                    <figure class="image"><img src="<?php echo esc_attr($image_gallery);?>" alt=""></figure>

                    <div class="overlay-box"><a href="<?php echo esc_attr($image_gallery);?>" class="lightbox-image" data-fancybox='gallery'><span class="icon fa fa-expand-arrows-alt"></span></a></div>

                </div>

            </div>

            <?php 

                    endwhile; ?>

            

            

            

        </div>

    </section>
    <?php endif; ?>	
    
    <?php if (is_admin()) { ?>
    <script type="text/javascript">
    
        
            
		jQuery('.gallery-carousel').owlCarousel({
			loop:true,
			margin:0,
			nav:true,
			smartSpeed: 500,
			autoplay: true,
			navText: [ '<span class="arrow_carrot-left"></span>', '<span class="arrow_carrot-right"></span>' ],
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				767:{
					items:3
				},
				800:{
					items:4
				},
				1200:{
					items:5
				}
			}
		}); 
	 
        
        
    </script>   
    <?php } ?>

	<?php

	}



}