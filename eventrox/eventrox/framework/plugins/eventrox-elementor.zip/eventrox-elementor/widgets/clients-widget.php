<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsClients extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-clients';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Clients', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-slideshow';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'clients', 'carousel' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_clients_select',

			[

				'label' => esc_html__( 'Clients Select', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'style_01'  => esc_html__( ' Clients Style 01 ', 'bdevs-elementor' ),

					'style_02' => esc_html__( 'Clients Style 02', 'bdevs-elementor' ),

					'style_03' => esc_html__( 'Clients Style 03', 'bdevs-elementor' ),

				],

				'default'   => ['style_01'],

			]

		);



		$this->end_controls_section();

		$this->start_controls_section(

			'section_content_clients',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

			]	

		);



		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),

				'label_block' => true,

				'condition' => [

							'chose_style' => ['style_01'],

						],

			]

		);		



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

				'condition' => [

							'chose_style' => ['style_01'],

						],

			]

		);	

		$this->add_control(

			'background_bg',

			[

				'label'       => esc_html__( 'Background Image', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

				'condition' => [

					'chose_style' => ['style_02'],

				],

			]

		);	

		$this->add_control(

			'background_bg_3',

			[

				'label'       => esc_html__( 'Background Image', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

				'condition' => [

					'chose_style' => ['style_03'],

				],

			]

		);

		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_clients',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'tabs2',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Clients #2', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'condition' => [

					'chose_style' => ['style_02'],

				],

				'fields' => [

					[

						'name'    => 'tab_image',

						'label'   => esc_html__( 'Image Clients', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link',

						'label'       => esc_html__( ' Link', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					

				],

			]

		);

		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_clients',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'tabs3',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Clients #3', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'condition' => [

					'chose_style' => ['style_03'],

				],

				'fields' => [

					[

						'name'    => 'tab_image',

						'label'   => esc_html__( 'Image Clients', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link',

						'label'       => esc_html__( ' Link', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					

				],

			]

		);

		$this->end_controls_section();

		$this->start_controls_section(

			'section_content_clients',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Clients', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'condition' => [

					'chose_style' => ['style_01'],

				],

				'fields' => [

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					[

						'name'    => 'tab_image1',

						'label'   => esc_html__( 'Image Clients 1', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link1',

						'label'       => esc_html__( ' Link Clients 1', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '#' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					[

						'name'    => 'tab_image2',

						'label'   => esc_html__( 'Image Clients 2', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link2',

						'label'       => esc_html__( ' Link Clients 2', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '#' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					[

						'name'    => 'tab_image3',

						'label'   => esc_html__( 'Image Clients 3', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link3',

						'label'       => esc_html__( ' Link Clients 3', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '#' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					[

						'name'    => 'tab_image4',

						'label'   => esc_html__( 'Image Clients 4', 'bdevs-elementor' ),

						'type'    => Controls_Manager::MEDIA,

						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						

					],

					[

						'name'        => 'link4',

						'label'       => esc_html__( ' Link Clients 4', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '#' , 'bdevs-elementor' ),

						'label_block' => true,

						

					],

					

				],

			]

		);



		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_image1',

			[

				'label'   => esc_html__( 'Show Image 1', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_image2',

			[

				'label'   => esc_html__( 'Show Image 2', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_image3',

			[

				'label'   => esc_html__( 'Show Image 3', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_image4',

			[

				'label'   => esc_html__( 'Show Image 4', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



	}



	public function render() {



		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

	$bg_src_3 = wp_get_attachment_image_src( $settings['background_bg_3']['id'], 'full' );

	$bg_url_3 = $bg_src_3 ? $bg_src_3[0] : '';

		?> 
		<h2 style="display: none;">11111</h2>
		<?php if( $chose_style == 'style_01' ): ?> 

		<section class="clients-section">

        <div class="anim-icons">

            <span class="icon icon-dots-3 wow zoomIn"></span>

            <span class="icon icon-circle-blue wow zoomIn"></span>

        </div>

        <div class="auto-container">
        	<h2 style="display: none;">11111</h2>
            <div class="sec-title">

            	<?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <?php

        	$idd = 0;

        	 foreach ( $settings['tabs'] as $item ) :

        	 $idd++;

        	  ?>

        	  <?php 

		   	if ( '' !== $item['tab_image1'] )  : 

		   		$image_src1 = wp_get_attachment_image_src( $item['tab_image1']['id'], 'full' );

				$image1 = $image_src1 ? $image_src1[0] : ''; 

		   		?>

			<?php 

			endif; ?>

			<?php 

		   	if ( '' !== $item['tab_image2'] )  : 

		   		$image_src2 = wp_get_attachment_image_src( $item['tab_image2']['id'], 'full' );

				$image2 = $image_src2 ? $image_src2[0] : ''; 

		   		?>

			<?php 

			endif; ?>

			<?php 

		   	if ( '' !== $item['tab_image3'] )  : 

		   		$image_src3 = wp_get_attachment_image_src( $item['tab_image3']['id'], 'full' );

				$image3 = $image_src3 ? $image_src3[0] : ''; 

		   		?>

			<?php 

			endif; ?>

			<?php 

		   	if ( '' !== $item['tab_image4'] )  : 

		   		$image_src4 = wp_get_attachment_image_src( $item['tab_image4']['id'], 'full' );

				$image4 = $image_src4 ? $image_src4[0] : ''; 

		   		?>

			<?php 

			endif; ?>

            <div class="sponsors-outer">

            	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                <h3><?php echo wp_kses_post($item['title']); ?></h3>

                <?php endif; ?>

                <div class="row">

                    <?php if (( '' !== $item['image1'] ) && ( $settings['show_image1'] )) : ?>

                    <div class="client-block col-lg-3 col-md-6 col-sm-12">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link1']); ?>"><img src="<?php print esc_url($image1); ?>" alt=""></a></figure>

                    </div>

                    <?php endif; ?>

                    <?php if (( '' !== $item['image2'] ) && ( $settings['show_image2'] )) : ?>

                    <div class="client-block col-lg-3 col-md-6 col-sm-12">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link2']); ?>"><img src="<?php print esc_url($image2); ?>" alt=""></a></figure>

                    </div>

                    <?php endif; ?>

                    <?php if (( '' !== $item['image3'] ) && ( $settings['show_image3'] )) : ?>

                    <div class="client-block col-lg-3 col-md-6 col-sm-12">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link3']); ?>"><img src="<?php print esc_url($image3); ?>" alt=""></a></figure>

                    </div>

                    <?php endif; ?>

                    <?php if (( '' !== $item['image4'] ) && ( $settings['show_image4'] )) : ?>

                    <div class="client-block col-lg-3 col-md-6 col-sm-12">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link4']); ?>"><img src="<?php print esc_url($image4); ?>" alt=""></a></figure>

                    </div>

                    <?php endif; ?>

                    

                    

                </div>

            </div>



            <?php

					endforeach;

					?>



            

        </div>

    </section>

    <?php elseif( $chose_style == 'style_02' ): ?>
    	
    	<section class="clients-section-two" style="background-image: url(<?php print esc_url( $bg_url ); ?>);">

        <div class="auto-container">
        	<h2 style="display: none;">11111</h2>
            <div class="sponsors-outer">

                <div class="row">

                	<?php

        	$idd = 0;

        	 foreach ( $settings['tabs2'] as $item ) :

        	 $idd++;

        	  ?>

        	  <?php 

		   	if ( '' !== $item['tab_image'] )  : 

		   		$image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

				$image = $image_src ? $image_src[0] : ''; 

		   		?>

			<?php 

			endif; ?>





                    <div class="client-block col-xl-2 col-lg-3 col-md-4 col-sm-6">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php print esc_url($image); ?>" alt=""></a></figure>

                    </div>





                    <?php

					endforeach;

					?>

                </div>

            </div>

        </div>

    </section>

    <?php elseif( $chose_style == 'style_03' ): ?>

    	<section class="clients-section-three" style="background-image: url(<?php print esc_url( $bg_url_3 ); ?>);">
    		<h2 style="display: none;">11111</h2>
        <div class="auto-container">

            <div class="sponsors-outer">

                <div class="sponsors-carousel owl-carousel owl-theme">

                	<?php

        	$idd = 0;

        	 foreach ( $settings['tabs3'] as $item ) :

        	 $idd++;

        	  ?>

        	  <?php 

		   	if ( '' !== $item['tab_image'] )  : 

		   		$image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

				$image = $image_src ? $image_src[0] : ''; 

		   		?>

			<?php 

			endif; ?>



					<div class="client-block">

                        <figure class="image-box"><a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php print esc_url($image); ?>" alt=""></a></figure>

                    </div>



                    <?php

					endforeach;

					?>

                </div>

            </div>

        </div>

    </section>
<?php if (is_admin()) { ?>
    <script type="text/javascript">
    
        
            
		jQuery('.sponsors-carousel').owlCarousel({
			loop:true,
			margin:30,
			nav:true,
			lazyLoad: true,
			smartSpeed: 700,
			autoplay: true,
			navText: [ '<span class="la la-angle-left"></span>', '<span class="la la-angle-right"></span>' ],
			responsive:{
				0:{
					items:1
				},
				600:{
					items:2
				},
				768:{
					items:3
				},
				1024:{
					items:4
				},
				1200:{
					items:5
				}
			}
		}); 
	 
        
        
    </script>   
    <?php } ?>
    <?php endif; ?>	

	<?php

	}

}