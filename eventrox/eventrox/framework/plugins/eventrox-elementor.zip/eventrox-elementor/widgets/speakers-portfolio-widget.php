<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsSpeakersPortfolio extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-speakers-portfolio';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Speakers Portfolio', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-slideshow';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'speakers portfolio', 'carousel' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_speakers',

			[

				'label' => esc_html__( 'Speakers Portfolio', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'style_01'  => esc_html__( 'Speakers Portfolio Style 1 ', 'bdevs-elementor' ),

					'style_02' => esc_html__( 'Speakers Portfolio Style 2 ', 'bdevs-elementor' ),

					'style_03' => esc_html__( 'Speakers Portfolio Style 3 ', 'bdevs-elementor' ),

				],

				'default'   => ['style_01'],

			]

		);

		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		

		$this->add_control(

			'background_bg',

			[

				'label'       => esc_html__( 'Background Image', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

				'condition' => [

					'chose_style' => ['style_02'],

				],

			]

		);

		$this->add_control(

			'post_number',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'4'  => esc_html__( '4', 'bdevs-elementor' ),

					'8' => esc_html__( '8', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

					'16' => esc_html__( '16', 'bdevs-elementor' ),

					'20' => esc_html__( '20', 'bdevs-elementor' ),

					'24' => esc_html__( '24', 'bdevs-elementor' ),

					'28' => esc_html__( '28', 'bdevs-elementor' ),

				],

				'default'   => '8',

			]

		);

		$this->add_control(

			'orderpost',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->add_control(

			'orderby',

			[

				'label'     => esc_html__( 'Order By', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'date'  => esc_html__( 'Date', 'bdevs-elementor' ),

					'title' => esc_html__( 'Title', 'bdevs-elementor' ),

					'rand' => esc_html__( 'Random', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);

		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		



		$this->end_controls_section();



	}



	public function render() {



		$settings  = $this->get_settings_for_display();

		$wp_query = new \WP_Query(array('posts_per_page' => $settings['post_number'],'post_type' => 'speakers',  'orderby' => $settings['orderby'], 'order' => $settings['orderpost']));

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

		?> 
<h2 style="display: none;">11111</h2>
<?php if( $chose_style == 'style_01' ): ?>

 <section class="speakers-section-two">

        <div class="anim-icons">

            <span class="icon icon-circle-4 wow zoomIn"></span>

            <span class="icon icon-circle-3 wow zoomIn"></span>

        </div>



        <div class="auto-container">

            <div class="sec-title text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>	

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>	

            </div>



            <div class="row">

                <?php 

                        $args = new \WP_Query(array(

	                    'post_type'     => 'Speakers',

	                	));

                $i = 1;

                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                $i++;

				?>

				<?php $job = get_post_meta(get_the_ID(),'_cmb_job', true); ?>

				<?php $facebook = get_post_meta(get_the_ID(),'_cmb_facebook', true); ?>

				<?php $twitter = get_post_meta(get_the_ID(),'_cmb_twitter', true); ?>

				<?php $pinterest = get_post_meta(get_the_ID(),'_cmb_pinterest', true); ?>

				<?php $dribbble = get_post_meta(get_the_ID(),'_cmb_dribbble', true); ?>



                <div class="speaker-block-two col-xl-3 col-lg-4 col-md-6 col-sm-12 wow fadeInUp">

                    <div class="inner-box">

                        <div class="info-box">

                            <h4 class="name"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"class="lightbox-image" data-fancybox='gallery'><?php the_title();?></a></h4>

                            <span class="designation"><?php echo esc_attr($job);?></span>

                        </div>

                        <div class="image-box">

                            <figure class="image"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"class="lightbox-image" data-fancybox='gallery'><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt=""></a></figure> 

                        </div>

                        <div class="social-box">                            

                            <ul class="social-links social-icon-colored">

                                <li><a href="<?php echo esc_attr($facebook);?>"><i class="fab fa-facebook-f"></i></a></li>

                                <li><a href="<?php echo esc_attr($twitter);?>"><i class="fab fa-twitter"></i></a></li>

                                <li><a href="<?php echo esc_attr($pinterest);?>"><i class="fab fa-pinterest"></i></a></li>

                                <li><a href="<?php echo esc_attr($dribbble);?>"><i class="fab fa-dribbble"></i></a></li>

                            </ul>

                        </div>

                    </div>

                </div>

                <?php 

                    endwhile; ?>

            </div>

        </div>

    </section>

    <?php elseif( $chose_style == 'style_02' ): ?>

    	<section class="speakers-section" style="background-image: url(<?php print esc_url( $bg_url ); ?>);">

        <div class="auto-container">

            <div class="sec-title light text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>	

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>	

            </div>



            <div class="row">

                <!-- Speaker Block -->

                <?php 

                        $args = new \WP_Query(array(

	                    'post_type'     => 'Speakers',

	                	));

                $i = 1;

                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                $i++;

				?>

				<?php $job = get_post_meta(get_the_ID(),'_cmb_job', true); ?>

				<?php $facebook = get_post_meta(get_the_ID(),'_cmb_facebook', true); ?>

				<?php $twitter = get_post_meta(get_the_ID(),'_cmb_twitter', true); ?>

				<?php $pinterest = get_post_meta(get_the_ID(),'_cmb_pinterest', true); ?>

				<?php $dribbble = get_post_meta(get_the_ID(),'_cmb_dribbble', true); ?>

                <div class="speaker-block col-xl-3 col-lg-4 col-md-6 col-sm-12">

                    <div class="inner-box">

                        <div class="image-box">

                            <figure class="image"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" class="lightbox-image" data-fancybox='gallery'><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt=""></a></figure> 

                        </div>

                        <div class="info-box">

                            <div class="inner">

                                <h4 class="name"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?> "class="lightbox-image" data-fancybox='gallery'><?php the_title();?></a></h4>

                                <span class="designation"><?php echo esc_attr($job);?></span>

                                <ul class="social-links social-icon-colored">

                                    <li><a href="<?php echo esc_attr($facebook);?>"><i class="fab fa-facebook-f"></i></a></li>

	                                <li><a href="<?php echo esc_attr($twitter);?>"><i class="fab fa-twitter"></i></a></li>

	                                <li><a href="<?php echo esc_attr($pinterest);?>"><i class="fab fa-pinterest"></i></a></li>

	                                <li><a href="<?php echo esc_attr($dribbble);?>"><i class="fab fa-dribbble"></i></a></li>

                                </ul>

                            </div>

                        </div>

                    </div>

                </div>

                <?php 

                    endwhile; ?>

            </div>

        </div>

    </section>

    <?php elseif( $chose_style == 'style_03' ): ?>

    	<section class="speakers-section-three">

        <div class="auto-container">

            <div class="sec-title text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>	

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>	

            </div>



            <div class="row">

                <?php 

                        $args = new \WP_Query(array(

	                    'post_type'     => 'Speakers',

	                	));

                $i = 1;

                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                $i++;

				?>

				<?php $job = get_post_meta(get_the_ID(),'_cmb_job', true); ?>

				<?php $facebook = get_post_meta(get_the_ID(),'_cmb_facebook', true); ?>

				<?php $twitter = get_post_meta(get_the_ID(),'_cmb_twitter', true); ?>

				<?php $pinterest = get_post_meta(get_the_ID(),'_cmb_pinterest', true); ?>

				<?php $dribbble = get_post_meta(get_the_ID(),'_cmb_dribbble', true); ?>

                <div class="speaker-block-three col-xl-3 col-lg-4 col-md-6 col-sm-12 wow fadeInUp">

                    <div class="inner-box">

                        <div class="image-box">

                            <figure class="image"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"class="lightbox-image" data-fancybox='gallery'><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt=""></a></figure> 

                        </div>

                        <div class="info-box">

                            <h4 class="name"><a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"class="lightbox-image" data-fancybox='gallery'><?php the_title();?></a></h4>

                            <span class="designation"><?php echo esc_attr($job);?></span>

                        </div>

                        <div class="social-box">                            

                            <ul class="social-links social-icon-colored">

                                <li><a href="<?php echo esc_attr($facebook);?>"><i class="fab fa-facebook-f"></i></a></li>

                                <li><a href="<?php echo esc_attr($twitter);?>"><i class="fab fa-twitter"></i></a></li>

                                <li><a href="<?php echo esc_attr($pinterest);?>"><i class="fab fa-pinterest"></i></a></li>

                                <li><a href="<?php echo esc_attr($dribbble);?>"><i class="fab fa-dribbble"></i></a></li>

                            </ul>

                        </div>

                    </div>

                </div>

                <?php 

                    endwhile; ?>

                

            </div>

        </div>

    </section>

    <?php endif; ?>	

	<?php

	}



}

