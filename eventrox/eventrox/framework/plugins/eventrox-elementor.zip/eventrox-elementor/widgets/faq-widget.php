<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsFAQS extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-faq';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'FAQS', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-slideshow';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'FAQS', 'carousel' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_speakers',

			[

				'label' => esc_html__( 'Speakers', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXTAREA,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		

		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_faq-left',

			[

				'label' => esc_html__( 'Speakers Items Left', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Speakers Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Speakers #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],				

					[

						'name'        => 'subtitle',

						'label'       => esc_html__( 'Subtitle Items', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXTAREA,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					

				],

			]

		);



		$this->end_controls_section();

		$this->start_controls_section(

			'section_content_faq-right',

			[

				'label' => esc_html__( 'Speakers Items Right', 'bdevs-elementor' ),

			]

		);

		$this->add_control(

			'tabs2',

			[

				'label' => esc_html__( 'Speakers Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Speakers #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],				

					[

						'name'        => 'subtitle',

						'label'       => esc_html__( 'Subtitle Items', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					

				],

			]

		);



		$this->end_controls_section();



		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_subtitle',

			[

				'label'   => esc_html__( 'Show Subtitle', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		



		$this->end_controls_section();



	}



	public function render() {



		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

		?> 
		<h2 style="display: none;">11111</h2>
		<section class="faq-section">

        <div class="auto-container">

            <!-- Sec Title -->

            <div class="sec-title">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <div class="row clearfix">

                <!-- Content Column -->

                <div class="content-column col-lg-6 col-md-12 col-sm-12">

                    <div class="inner-column">

                        <!--Accordian Box-->

                        <ul class="accordion-box">

                            <!--Block-->

                            <?php

        	$idd = 0;

        	 foreach ( $settings['tabs'] as $item ) :

        	 $idd++;

        	  ?>

        	 <?php 

		   	if ( '' !== $item['tab_image'] )  : 

		   		$image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

				$image = $image_src ? $image_src[0] : ''; 

		   		?>

			<?php 

			endif; ?>

                            <?php if ($idd=='1') { ?>

                            <li class="accordion block active-block wow fadeInUp">

                            	<div class="acc-btn active">

                            	<?php } else { ?>

                            	<li class="accordion block wow fadeInUp">

                            		<div class="acc-btn">

                            	<?php } ?>

                            	

                                

                                	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?><div class="icon-outer"><span class="icon icon-plus fa fa-angle-down"></span> </div><?php echo wp_kses_post($item['title']); ?></div>

                                <?php endif; ?>

                                <?php if (( '' !== $item['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>

                                <?php if ($idd=='1') { ?>

                                <div class="acc-content current">

                                <?php } else { ?>

                                <div class="acc-content">

                                <?php } ?>

                                    <div class="content">

                                        <div class="text"><?php echo wp_kses_post($item['subtitle']); ?></div>

                                    </div>

                                </div>

                                <?php endif; ?>

                            </li>

                    <?php

					endforeach;

					?>

                            

                        </ul>

                    </div>

                </div>



                <!-- Content Column -->

                <div class="content-column col-lg-6 col-md-12 col-sm-12">

                    <div class="inner-column">

                        <!--Accordian Box-->

                        <ul class="accordion-box">

                            <!--Block-->

                            <?php

        	$idd = 0;

        	 foreach ( $settings['tabs2'] as $item ) :

        	 $idd++;

        	  ?>

        	 <?php 

		   	if ( '' !== $item['tab_image'] )  : 

		   		$image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

				$image = $image_src ? $image_src[0] : ''; 

		   		?>

			<?php 

			endif; ?>

							<?php if ($idd=='1') { ?>

                            <li class="accordion block active-block wow fadeInUp">

                            	<div class="acc-btn active">

                            	<?php } else { ?>

                            	<li class="accordion block wow fadeInUp">

                            		<div class="acc-btn">

                            	<?php } ?>

                            	

                                

                                	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?><div class="icon-outer"><span class="icon icon-plus fa fa-angle-down"></span> </div><?php echo wp_kses_post($item['title']); ?></div>

                                <?php endif; ?>

                                <?php if (( '' !== $item['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>

                                <?php if ($idd=='1') { ?>

                                <div class="acc-content current">

                                <?php } else { ?>

                                <div class="acc-content">

                                <?php } ?>

                                    <div class="content">

                                        <div class="text"><?php echo wp_kses_post($item['subtitle']); ?></div>

                                    </div>

                                </div>

                                <?php endif; ?>

                            </li>

                         <?php

					endforeach;

					?>   





                        </ul>

                    </div>

                </div>

            </div>

        </div>

    </section>

	<?php

	}



}

