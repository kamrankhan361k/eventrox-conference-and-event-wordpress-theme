<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsPricing extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-pricing';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Pricing', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'pricing' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_pricing',

			[

				'label' => esc_html__( 'Pricing', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'style_01'  => esc_html__( 'Pricing Style 1 ', 'bdevs-elementor' ),

					'style_02' => esc_html__( 'Pricing Style 2 ', 'bdevs-elementor' ),

					'style_03' => esc_html__( 'Pricing Style 3 ', 'bdevs-elementor' ),

				],

				'default'   => ['style_01'],

			]

		);

		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);		

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Fun Fact Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],	

					[

						'name'        => 'pricing',

						'label'       => esc_html__( 'Pricing', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Pricing' , 'bdevs-elementor' ),

						'label_block' => true,s

					],	

					[

						'name'        => 'desc',

						'label'       => esc_html__( 'Description', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXTAREA,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Description' , 'bdevs-elementor' ),

						'label_block' => true,s

					],

					[

						'name'        => 'link',

						'label'       => esc_html__( 'Link Button', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( '#' , 'bdevs-elementor' ),

						'label_block' => true,s

					],

					[

						'name'        => 'button',

						'label'       => esc_html__( 'Button', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Buy Ticket' , 'bdevs-elementor' ),

						'label_block' => true,s

					],

					

					

				],

			]

		);	



		$this->end_controls_section();



		/** 

		*	Layout section 

		**/

		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);

		



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->add_control(

			'show_icon',

			[

				'label'   => esc_html__( 'Show Icon', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_pricing',

			[

				'label'   => esc_html__( 'Show Pricing', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_desc',

			[

				'label'   => esc_html__( 'Show Description', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

	?> 
<h2 style="display: none;">11111</h2>
	<?php if( $chose_style == 'style_01' ): ?>

<section class="pricing-section">

        <div class="anim-icons">

            <span class="icon icon-circle-green wow fadeIn"></span>

            <span class="icon icon-circle-blue wow fadeIn"></span>

            <span class="icon icon-circle-pink wow fadeIn"></span>

        </div>



        <div class="auto-container">

            <div class="sec-title text-center">

            	<?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <div class="outer-box">

                <div class="row">

                    <!-- Pricing Block -->

                    <?php

		        	$idd = 0;

		        	 foreach ( $settings['tabs'] as $item ) :

		        	 $idd++;

		        	  ?>

		        	  <?php if ($idd=='1') { ?>

                    <div class="pricing-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <div class="icon-box">

                                <div class="icon-outer"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span></div>

                            </div>

                            <?php endif; ?>

                            <div class="price-box">

                            	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                <div class="title"> <?php echo wp_kses_post($item['title']); ?></div>

                                <?php endif; ?>

                                <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                <?php endif; ?>

                            </div>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                    <?php } elseif ($idd=='2') { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <div class="icon-box">

                                <div class="icon-outer"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span></div>

                            </div>

                            <?php endif; ?>

                            <div class="price-box">

                            	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                <div class="title"> <?php echo wp_kses_post($item['title']); ?></div>

                                <?php endif; ?>

                                <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                <?php endif; ?>

                            </div>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } else { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <div class="icon-box">

                                <div class="icon-outer"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span></div>

                            </div>

                            <?php endif; ?>

                            <div class="price-box">

                            	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                <div class="title"> <?php echo wp_kses_post($item['title']); ?></div>

                                <?php endif; ?>

                                <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                <?php endif; ?>

                            </div>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                    <?php } ?>

                    <?php

					endforeach;

					?>

                </div>

            </div>

        </div>

    </section>



<?php elseif( $chose_style == 'style_02' ): ?>

    <section class="pricing-section-two">

        <div class="anim-icons">

            <span class="icon icon-line-1 wow zoomIn"></span>

            <span class="icon icon-circle-1 wow zoomIn"></span>

            <span class="icon icon-dots wow zoomIn"></span>

        </div>



        <div class="auto-container">

            <div class="sec-title text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <div class="outer-box">

                <div class="row">

                    <!-- Pricing Block -->



                     <?php

		        	$idd = 0;

		        	 foreach ( $settings['tabs'] as $item ) :

		        	 $idd++;

		        	  ?>

		        	  <?php if ($idd=='1') { ?>

                    <div class="pricing-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>



                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <div class="price-box">

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                

                            </div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                            

                        </div>

                    </div>

                    <?php } elseif ($idd=='2') { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>



                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <div class="price-box">

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                

                            </div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                            

                        </div>

                    </div>

                    <?php } else { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="1200ms">

                        <div class="inner-box">

                        	<?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>



                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <div class="price-box">

                                <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                                

                            </div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                            

                        </div>

                    </div>

                    <?php } ?>

                    <?php

					endforeach;

					?>





                </div>

            </div>

        </div>

    </section>

    <?php elseif( $chose_style == 'style_03' ): ?>

    <section class="pricing-section-three">

        <div class="anim-icons">

            <span class="icon icon-line-1 wow zoomIn"></span>

            <span class="icon icon-circle-1 wow zoomIn"></span>

            <span class="icon icon-dots wow zoomIn"></span>

        </div>



        <div class="auto-container">

            <div class="sec-title text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <div class="outer-box">

                <div class="row">

                    <!-- Pricing Block -->

                    <?php

		        	$idd = 0;

		        	 foreach ( $settings['tabs'] as $item ) :

		        	 $idd++;

		        	  ?>

		        	  <?php if ($idd=='1') { ?>

                    <div class="pricing-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">

                        <div class="inner-box">

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                    <?php } elseif ($idd=='2') { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">

                        <div class="inner-box">

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                    <?php } else { ?>

                    <!-- Pricing Block -->

                    <div class="pricing-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="1200ms">

                        <div class="inner-box">

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <div class="title"><span class="<?php echo wp_kses_post($item['icon']); ?>"></span> <?php echo wp_kses_post($item['title']); ?></div>

                            <?php endif; ?>

                            <?php if (( '' !== $item['pricing'] ) && ( $settings['show_pricing'] )) : ?>

                            <h4 class="price"><?php echo wp_kses_post($item['pricing']); ?></h4>

                            <?php endif; ?>

                            <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                            <ul class="features">

                                <?php echo wp_kses_post($item['desc']); ?>

                            </ul>

                            <?php endif; ?>

                            <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                            <div class="btn-box">

                                <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn btn-style-one"><span class="btn-title"><?php echo wp_kses_post($item['button']); ?></span></a>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>



                   <?php } ?>

                    <?php

					endforeach;

					?> 



                </div>

            </div>

        </div>

    </section>

    <?php endif; ?>	

	<?php

	}



}