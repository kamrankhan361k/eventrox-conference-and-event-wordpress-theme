<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsSchedule2 extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-schedule2';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Schedule Home 2', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'schedule2' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_schedule_2',

			[

				'label' => esc_html__( 'Schedule', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Type section title here', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'subheading',

			[

				'label'       => __( 'Subheading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXTAREA,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

			]

		);

		$this->end_controls_section();







		$this->start_controls_section(

			'section_tab_title',

			[

				'label' => esc_html__( 'Schedule Tab Title', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'About Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'About #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					],

				],

				'fields' => [					

					[

						'name'        => 'day',

						'label'       => esc_html__( 'Day', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Day from here', 'bdevs-elementor' ),

					],					

					[

						'name'        => 'date',

						'label'       => esc_html__( 'Date', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => __( 'It is Date.', 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'       => 'month',

						'label'      => esc_html__( 'Month', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'year',

						'label'      => esc_html__( 'Year', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

				],

			]

		);

		$this->end_controls_section();

		$this->start_controls_section(

			'section_tab_1',

			[

				'label' => esc_html__( 'Schedule Tab 1', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'tabs1',

			[

				'label' => esc_html__( 'Schedule Tab 1', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Schedule #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					],

				],

				'fields' => [					

					[

						'name'        => 'time_event',

						'label'       => esc_html__( 'Time Event', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Time Event from here', 'bdevs-elementor' ),

					],					

					[

						'name'        => 'tab_image',

						'label'       => esc_html__( 'Avata', 'bdevs-elementor' ),

						'type'        => Controls_Manager::MEDIA,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Avata from here', 'bdevs-elementor' ),
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
					],

					[

						'name'       => 'name',

						'label'      => esc_html__( 'Name', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'job',

						'label'      => esc_html__( 'Job', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'title',

						'label'      => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'desc',

						'label'      => esc_html__( 'Description', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXTAREA,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'link',

						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'button',

						'label'      => esc_html__( 'Button', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

				],

			]

		);

		$this->end_controls_section();

		$this->start_controls_section(

			'section_tab_2',

			[

				'label' => esc_html__( 'Schedule Tab 2', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'tabs2',

			[

				'label' => esc_html__( 'Schedule Tab 2', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Schedule #2', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					],

				],

				'fields' => [					

					[

						'name'        => 'time_event',

						'label'       => esc_html__( 'Time Event', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Time Event from here', 'bdevs-elementor' ),

					],					

					[

						'name'        => 'tab_image',

						'label'       => esc_html__( 'Avata', 'bdevs-elementor' ),

						'type'        => Controls_Manager::MEDIA,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Avata from here', 'bdevs-elementor' ),
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
					],

					[

						'name'       => 'name',

						'label'      => esc_html__( 'Name', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'job',

						'label'      => esc_html__( 'Job', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'title',

						'label'      => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'desc',

						'label'      => esc_html__( 'Description', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXTAREA,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'link',

						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'button',

						'label'      => esc_html__( 'Button', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

				],

			]

		);

		$this->end_controls_section();

		$this->start_controls_section(

			'section_tab_3',

			[

				'label' => esc_html__( 'Schedule Tab 3', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'tabs3',

			[

				'label' => esc_html__( 'Schedule Tab 3', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Schedule #2', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					],

				],

				'fields' => [					

					[

						'name'        => 'time_event',

						'label'       => esc_html__( 'Time Event', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Time Event from here', 'bdevs-elementor' ),

					],					

					[

						'name'        => 'tab_image',

						'label'       => esc_html__( 'Avata', 'bdevs-elementor' ),

						'type'        => Controls_Manager::MEDIA,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Avata from here', 'bdevs-elementor' ),
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
					],

					[

						'name'       => 'name',

						'label'      => esc_html__( 'Name', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'job',

						'label'      => esc_html__( 'Job', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'title',

						'label'      => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'desc',

						'label'      => esc_html__( 'Description', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXTAREA,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'link',

						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'button',

						'label'      => esc_html__( 'Button', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

				],

			]

		);

		$this->end_controls_section();

		$this->start_controls_section(

			'section_tab_4',

			[

				'label' => esc_html__( 'Schedule Tab 4', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'tabs4',

			[

				'label' => esc_html__( 'Schedule Tab 4', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Schedule #4', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					],

				],

				'fields' => [					

					[

						'name'        => 'time_event',

						'label'       => esc_html__( 'Time Event', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Time Event from here', 'bdevs-elementor' ),

					],					

					[

						'name'        => 'tab_image',

						'label'       => esc_html__( 'Avata', 'bdevs-elementor' ),

						'type'        => Controls_Manager::MEDIA,

						'dynamic'     => [ 'active' => true ],

						'label_block' => true,

						'description' => esc_html__( 'Upload Avata from here', 'bdevs-elementor' ),
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
					],

					[

						'name'       => 'name',

						'label'      => esc_html__( 'Name', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'job',

						'label'      => esc_html__( 'Job', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'title',

						'label'      => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'desc',

						'label'      => esc_html__( 'Description', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXTAREA,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'link',

						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

					[

						'name'       => 'button',

						'label'      => esc_html__( 'Button', 'bdevs-elementor' ),

						'type'       => Controls_Manager::TEXT,

						'dynamic'    => [ 'active' => true ],

						'show_label' => true,

					],

				],

			]

		);

		$this->end_controls_section();

		/** 

		*	Layout section 

		**/

		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);			



		$this->add_control(

			'show_subheading',

			[

				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		

		$this->add_control(

			'show_day',

			[

				'label'   => esc_html__( 'Show Day', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);	

		$this->add_control(

			'show_date',

			[

				'label'   => esc_html__( 'Show Date', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_month',

			[

				'label'   => esc_html__( 'Show Month', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_year',

			[

				'label'   => esc_html__( 'Show Year', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_time_event',

			[

				'label'   => esc_html__( 'Show Time Event', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_name',

			[

				'label'   => esc_html__( 'Show Name', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_job',

			[

				'label'   => esc_html__( 'Show Job', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_desc',

			[

				'label'   => esc_html__( 'Show Description', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		extract($settings);?> 
		<h2 style="display: none;">11111</h2>
	<section class="schedule-section style-two">

        <div class="auto-container">

            <div class="sec-title text-center">

                <?php if (( '' !== $settings['subheading'] ) && ( $settings['show_subheading'] )) : ?>

                <span class="title"><?php echo wp_kses_post($settings['subheading']); ?></span>

                <?php endif; ?>

                <?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )) : ?>

                <h2><?php echo wp_kses_post($settings['heading']); ?></h2>

                <?php endif; ?>

            </div>



            <div class="schedule-tabs style-two tabs-box">

                <div class="btns-box">

                    <!--Tabs Box-->

                    <ul class="tab-buttons clearfix">

                        <?php

				        $idd = 0;

				        foreach ( $settings['tabs'] as $item ) :

				        $idd++;

				        ?>

            			<?php if ($idd=='1') { ?>

                        <li class="tab-btn active-btn " data-tab="#tab-<?php echo esc_attr($idd);?>">

                        <?php } else { ?>

                        <li class="tab-btn" data-tab="#tab-<?php echo esc_attr($idd);?>">

                        <?php } ?>

                        	<?php if (( '' !== $item['day'] ) && ( $settings['show_day'] )) : ?>

                            <span class="day"><?php echo wp_kses_post($item['day']); ?></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['date'] ) && ( $settings['show_date'] )) : ?>

                            <span class="date"><?php echo wp_kses_post($item['date']); ?></span> 

                            <?php endif; ?>

                            <?php if (( '' !== $item['month'] ) && ( $settings['show_month'] )) : ?>

                            <span class="month"><?php echo wp_kses_post($item['month']); ?></span> <?php echo wp_kses_post($item['year']); ?>

            				<?php endif; ?>

                        </li>

                        <?php endforeach; ?>

                    </ul>

                </div>



                <div class="tabs-content">



                    <!--Tab-->

                    <div class="tab active-tab" id="tab-1">

                        <div class="schedule-timeline">



                             <?php 

                	$idd = 0;

		           foreach ( $settings['tabs1'] as $item ) :

		           $idd++;

		           ?>

		          <?php if ( '' !== $item['tab_image'] )  : 

		            $image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

		            $image = $image_src ? $image_src[0] : ''; ?>

		          <?php endif; ?>





                            

                            <div class="schedule-block">

                                <div class="inner-box">

                                    <div class="inner">

                                    	<?php if (( '' !== $item['time_event'] ) && ( $settings['show_time_event'] )) : ?>

                                        <div class="date"><?php echo wp_kses_post($item['time_event']); ?></div>

                                        <?php endif; ?>

                                        <div class="speaker-info">

                                            <figure class="thumb"><img src="<?php print esc_url($image); ?>" alt=""></figure>

                                            <?php if (( '' !== $item['name'] ) && ( $settings['show_name'] )) : ?>

                                            <h5 class="name"><?php echo wp_kses_post($item['name']); ?></h5>

                                            <?php endif; ?>

                                            <?php if (( '' !== $item['job'] ) && ( $settings['show_job'] )) : ?>

                                            <span class="designation"><?php echo wp_kses_post($item['job']); ?></span>

                                            <?php endif; ?>

                                        </div>

                                        <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                        <h4><a href="<?php echo wp_kses_post($item['link']); ?>"><?php echo wp_kses_post($item['title']); ?></a></h4>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                                        <div class="text"><?php echo wp_kses_post($item['desc']); ?></div>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                                        <div class="btn-box">

                                            <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                                        </div>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                            <?php endforeach; ?>



                        </div>

                    </div>



                    <!--Tab-->

                    <div class="tab" id="tab-2">

                        <div class="schedule-timeline">

                            <!-- schedule Block -->

                            <?php 

                	$idd = 0;

		           foreach ( $settings['tabs2'] as $item ) :

		           $idd++;

		           ?>

		          <?php if ( '' !== $item['tab_image'] )  : 

		            $image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

		            $image = $image_src ? $image_src[0] : ''; ?>

		          <?php endif; ?>

                            <div class="schedule-block">

                                <div class="inner-box">

                                    <div class="inner">

                                    	<?php if (( '' !== $item['time_event'] ) && ( $settings['show_time_event'] )) : ?>

                                        <div class="date"><?php echo wp_kses_post($item['time_event']); ?></div>

                                        <?php endif; ?>

                                        <div class="speaker-info">

                                            <figure class="thumb"><img src="<?php print esc_url($image); ?>" alt=""></figure>

                                            <?php if (( '' !== $item['name'] ) && ( $settings['show_name'] )) : ?>

                                            <h5 class="name"><?php echo wp_kses_post($item['name']); ?></h5>

                                            <?php endif; ?>

                                            <?php if (( '' !== $item['job'] ) && ( $settings['show_job'] )) : ?>

                                            <span class="designation"><?php echo wp_kses_post($item['job']); ?></span>

                                            <?php endif; ?>

                                        </div>

                                        <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                        <h4><a href="<?php echo wp_kses_post($item['link']); ?>"><?php echo wp_kses_post($item['title']); ?></a></h4>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                                        <div class="text"><?php echo wp_kses_post($item['desc']); ?></div>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                                        <div class="btn-box">

                                            <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                                        </div>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                            <?php endforeach; ?>

                        </div>

                    </div>



                    <!--Tab-->

                    <div class="tab" id="tab-3">

                        <div class="schedule-timeline">

                            <!-- schedule Block -->                            <?php 

                	$idd = 0;

		           foreach ( $settings['tabs3'] as $item ) :

		           $idd++;

		           ?>

		          <?php if ( '' !== $item['tab_image'] )  : 

		            $image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

		            $image = $image_src ? $image_src[0] : ''; ?>

		          <?php endif; ?>

                            <div class="schedule-block">

                                <div class="inner-box">

                                    <div class="inner">

                                    	<?php if (( '' !== $item['time_event'] ) && ( $settings['show_time_event'] )) : ?>

                                        <div class="date"><?php echo wp_kses_post($item['time_event']); ?></div>

                                        <?php endif; ?>

                                        <div class="speaker-info">

                                            <figure class="thumb"><img src="<?php print esc_url($image); ?>" alt=""></figure>

                                            <?php if (( '' !== $item['name'] ) && ( $settings['show_name'] )) : ?>

                                            <h5 class="name"><?php echo wp_kses_post($item['name']); ?></h5>

                                            <?php endif; ?>

                                            <?php if (( '' !== $item['job'] ) && ( $settings['show_job'] )) : ?>

                                            <span class="designation"><?php echo wp_kses_post($item['job']); ?></span>

                                            <?php endif; ?>

                                        </div>

                                        <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                        <h4><a href="<?php echo wp_kses_post($item['link']); ?>"><?php echo wp_kses_post($item['title']); ?></a></h4>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                                        <div class="text"><?php echo wp_kses_post($item['desc']); ?></div>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                                        <div class="btn-box">

                                            <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                                        </div>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                            <?php endforeach; ?>

                        </div>

                    </div>



                    <!--Tab-->

                    <div class="tab" id="tab-4">

                        <div class="schedule-timeline">

                            <!-- schedule Block -->

                            <?php 

                	$idd = 0;

		           foreach ( $settings['tabs2'] as $item ) :

		           $idd++;

		           ?>

		          <?php if ( '' !== $item['tab_image'] )  : 

		            $image_src = wp_get_attachment_image_src( $item['tab_image']['id'], 'full' );

		            $image = $image_src ? $image_src[0] : ''; ?>

		          <?php endif; ?>

                            <div class="schedule-block">

                                <div class="inner-box">

                                    <div class="inner">

                                    	<?php if (( '' !== $item['time_event'] ) && ( $settings['show_time_event'] )) : ?>

                                        <div class="date"><?php echo wp_kses_post($item['time_event']); ?></div>

                                        <?php endif; ?>

                                        <div class="speaker-info">

                                            <figure class="thumb"><img src="<?php print esc_url($image); ?>" alt=""></figure>

                                            <?php if (( '' !== $item['name'] ) && ( $settings['show_name'] )) : ?>

                                            <h5 class="name"><?php echo wp_kses_post($item['name']); ?></h5>

                                            <?php endif; ?>

                                            <?php if (( '' !== $item['job'] ) && ( $settings['show_job'] )) : ?>

                                            <span class="designation"><?php echo wp_kses_post($item['job']); ?></span>

                                            <?php endif; ?>

                                        </div>

                                        <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                                        <h4><a href="<?php echo wp_kses_post($item['link']); ?>"><?php echo wp_kses_post($item['title']); ?></a></h4>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['desc'] ) && ( $settings['show_desc'] )) : ?>

                                        <div class="text"><?php echo wp_kses_post($item['desc']); ?></div>

                                        <?php endif; ?>

                                        <?php if (( '' !== $item['button'] ) && ( $settings['show_button'] )) : ?>

                                        <div class="btn-box">

                                            <a href="<?php echo wp_kses_post($item['link']); ?>" class="theme-btn"><?php echo wp_kses_post($item['button']); ?></a>

                                        </div>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                            <?php endforeach; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

		

	<?php

	}



}