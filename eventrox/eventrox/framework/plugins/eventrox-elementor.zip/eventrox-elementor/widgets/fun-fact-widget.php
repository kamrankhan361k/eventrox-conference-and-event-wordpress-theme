<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsFunFact extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-fun-fact';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Fun Fact', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'about' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_fun_fact',

			[

				'label' => esc_html__( 'Fun Fact', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'style_01'  => esc_html__( 'Fun Fact ', 'bdevs-elementor' ),

					'style_02' => esc_html__( 'Fun Fact Background ', 'bdevs-elementor' ),

				],

				'default'   => ['style_01'],

			]

		);



		$this->end_controls_section();

		$this->start_controls_section(

			'fun_fact',

			[

				'label' => esc_html__( 'fun_fact', 'bdevs-elementor' ),

			]	

		);

		$this->add_control(

			'background_bg',

			[

				'label'       => esc_html__( 'Background Image', 'bdevs-elementor' ),

				'type'        => Controls_Manager::MEDIA,

				'dynamic'     => [ 'active' => true ],

				'label_block' => true,

				'description' => esc_html__( 'Upload Background Image', 'bdevs-elementor' ),

				'condition' => [

					'chose_style' => ['style_02'],

				],

			]

		);

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Fun Fact Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [

					[

						'name'        => 'icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'number',

						'label'       => esc_html__( 'Number', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Number' , 'bdevs-elementor' ),

						'label_block' => true,s

					],

					[

						'name'        => 'title',

						'label'       => esc_html__( ' Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( ' Title Items' , 'bdevs-elementor' ),

						'label_block' => true,

					],		

					

					

				],

			]

		);	



		

		



		$this->end_controls_section();



		/** 

		*	Layout section 

		**/

		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);

		



		$this->add_control(

			'show_icon',

			[

				'label'   => esc_html__( 'Show Icon', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_number',

			[

				'label'   => esc_html__( 'Show Number', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->add_control(

			'show_title',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);

		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		extract($settings);

		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );

	$bg_url = $bg_src ? $bg_src[0] : '';

	?> 
	<h2 style="display: none;">11111</h2>
	<?php if( $chose_style == 'style_01' ): ?>

<section class="fun-fact-section">

        <div class="auto-container">

            <div class="fact-counter">

                <div class="row clearfix">



                    <!--Column-->

                    <?php

        	$idd = 0;

        	 foreach ( $settings['tabs'] as $item ) :

        	 $idd++;

        	  ?>

        	  <?php if ($idd=='1') { ?>



                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } elseif ($idd=='2') { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } elseif ($idd=='3') { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } else { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="1200ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } ?>

                    <?php

					endforeach;

					?>

                </div>

            </div>

        </div>

    </section>

    <?php elseif( $chose_style == 'style_02' ): ?>

    	<section class="fun-fact-section style-two" style="background-image: url(<?php print esc_url($bg_url); ?>);">

        <div class="auto-container">

            <div class="fact-counter">

                <div class="row clearfix">



                    <!--Column-->

                    <?php

        	$idd = 0;

        	 foreach ( $settings['tabs'] as $item ) :

        	 $idd++;

        	  ?>

        	  <?php if ($idd=='1') { ?>



                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } elseif ($idd=='2') { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } elseif ($idd=='3') { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } else { ?>

                    <!--Column-->

                    <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="1200ms">

                        <div class="count-box">

                        	<?php if (( '' !== $item['icon'] ) && ( $settings['show_icon'] )) : ?>

                            <span class="<?php echo wp_kses_post($item['icon']); ?>"></span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['number'] ) && ( $settings['show_number'] )) : ?>

                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses_post($item['number']); ?>">0</span>

                            <?php endif; ?>

                            <?php if (( '' !== $item['title'] ) && ( $settings['show_title'] )) : ?>

                            <h4 class="counter-title"><?php echo wp_kses_post($item['title']); ?></h4>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php } ?>

                    <?php

					endforeach;

					?>

                </div>

            </div>

        </div>

    </section>

    <?php endif; ?>	
	<?php if (is_admin()) { ?>
    <script type="text/javascript">
    
        
            
		jQuery('.count-box').appear(function(){
	
			var $t = $(this),
				n = $t.find(".count-text").attr("data-stop"),
				r = parseInt($t.find(".count-text").attr("data-speed"), 10);
				
			if (!$t.hasClass("counted")) {
				$t.addClass("counted");
				$({
					countNum: $t.find(".count-text").text()
				}).animate({
					countNum: n
				}, {
					duration: r,
					easing: "linear",
					step: function() {
						$t.find(".count-text").text(Math.floor(this.countNum));
					},
					complete: function() {
						$t.find(".count-text").text(this.countNum);
					}
				});
			}
			
		},{accY: 0});
	 	jQuery('.time-countdown').each(function() {
		var $this = $(this), finalDate = $(this).data('countdown');
		$this.countdown(finalDate, function(event) {
			var $this = $(this).html(event.strftime('' + '<div class="counter-column"><span class="count">%D</span>Days</div> ' + '<div class="counter-column"><span class="count">%H</span>Hours</div>  ' + '<div class="counter-column"><span class="count">%M</span>Minutes</div>  ' + '<div class="counter-column"><span class="count">%S</span>Second</div>'));
		});
	 });
        
        
    </script>   
    <?php } ?>


	<?php

	}



}